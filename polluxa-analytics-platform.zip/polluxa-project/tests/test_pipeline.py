"""
Part 7/8: automated tests that gate CI/CD deployment, and that back the
required live-demonstration scenarios (resilient recovery, bad-data
rejection, end-to-end refresh).
"""

import os
import sqlite3
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pipeline.load_warehouse import run_pipeline, get_conn, ensure_schema, DB_PATH
from dq.run_dq_checks import run_dq_suite


def setup_module(module):
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)


def test_pipeline_runs_successfully():
    run_id = run_pipeline()
    assert run_id is not None
    conn = get_conn()
    status = conn.execute(
        "SELECT status FROM pipeline_run_log WHERE run_id = ?", (run_id,)
    ).fetchone()[0]
    conn.close()
    assert status == "success"


def test_pipeline_is_idempotent_on_rerun():
    conn = get_conn()
    count_before = conn.execute("SELECT COUNT(*) FROM fact_outreach_event").fetchone()[0]
    conn.close()

    run_id_2 = run_pipeline()

    conn = get_conn()
    count_after = conn.execute("SELECT COUNT(*) FROM fact_outreach_event").fetchone()[0]
    rows_out_2 = conn.execute(
        "SELECT rows_out FROM pipeline_run_log WHERE run_id = ?", (run_id_2,)
    ).fetchone()[0]
    conn.close()

    assert count_after == count_before, "re-running the pipeline must not duplicate rows"
    assert rows_out_2 == 0, "second run against unchanged source should load zero new rows"


def test_bad_records_are_captured_in_dead_letter_not_silently_dropped():
    conn = get_conn()
    dead_letter_count = conn.execute("SELECT COUNT(*) FROM dead_letter_events").fetchone()[0]
    conn.close()
    assert dead_letter_count > 0, "synthetic fixture data includes deliberately malformed rows"


def test_referential_integrity_orphans_are_rejected():
    conn = get_conn()
    orphan_rejections = conn.execute(
        "SELECT COUNT(*) FROM dead_letter_events WHERE reject_reason LIKE '%referential integrity%'"
    ).fetchone()[0]
    conn.close()
    assert orphan_rejections > 0


def test_dq_suite_passes_on_clean_load():
    composite, result = run_dq_suite()
    assert composite >= 0.90
    assert result == "PASS"


def test_event_id_uniqueness_enforced_at_schema_level():
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) FROM fact_outreach_event").fetchone()[0]
    distinct = conn.execute("SELECT COUNT(DISTINCT event_id) FROM fact_outreach_event").fetchone()[0]
    conn.close()
    assert total == distinct
