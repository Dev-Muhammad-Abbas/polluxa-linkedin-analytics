# Power BI Engineering — Data Model & DAX Measure Layer

## Data model (import from warehouse.db tables via ODBC/SQLite connector,
or re-point at the equivalent Postgres/Snowflake tables in production)

Tables loaded into the model:
- `dim_agent` (current rows only: filter `is_current = 1` in Power Query for the
  default view; full history stays queryable for SCD drill-through)
- `dim_lead`
- `dim_campaign`
- `dim_date` (marked as the model's official **Date Table** in Power BI)
- `fact_outreach_event` (event-grain fact)
- `fact_daily_agent_summary` (day/agent-grain fact — primary source for the
  dashboard visuals; `fact_outreach_event` backs drill-through detail pages)

Relationships (all single-direction, fact → dimension):
- `fact_daily_agent_summary[agent_sk]` → `dim_agent[agent_sk]`
- `fact_daily_agent_summary[date_sk]` → `dim_date[date_sk]`
- `fact_outreach_event[agent_sk]` → `dim_agent[agent_sk]`
- `fact_outreach_event[lead_sk]` → `dim_lead[lead_sk]`
- `fact_outreach_event[campaign_sk]` → `dim_campaign[campaign_sk]`
- `fact_outreach_event[date_sk]` → `dim_date[date_sk]`

---

## Core KPI measures

```dax
Invites Sent =
CALCULATE(
    COUNTROWS(fact_outreach_event),
    fact_outreach_event[event_type] = "invite_sent"
)

Invites Accepted =
CALCULATE(
    COUNTROWS(fact_outreach_event),
    fact_outreach_event[event_type] = "invite_accepted"
)

Messages Sent =
CALCULATE(
    COUNTROWS(fact_outreach_event),
    fact_outreach_event[event_type] = "message_sent"
)

Replies Received =
CALCULATE(
    COUNTROWS(fact_outreach_event),
    fact_outreach_event[event_type] = "reply_received"
)

Acceptance Rate =
DIVIDE([Invites Accepted], [Invites Sent], BLANK())

Reply Rate =
DIVIDE([Replies Received], [Messages Sent], BLANK())

Conversion Rate (Invite to Reply) =
DIVIDE([Replies Received], [Invites Sent], BLANK())

Daily Invite Limit (Current) =
CALCULATE(
    SUM(dim_agent[daily_invite_limit]),
    dim_agent[is_current] = TRUE()
)

Throughput vs Limit % =
DIVIDE([Invites Sent], [Daily Invite Limit (Current)], BLANK())
```

## Account health measures

```dax
Active Agent Count =
CALCULATE(
    DISTINCTCOUNT(dim_agent[agent_id]),
    dim_agent[status] = "active",
    dim_agent[is_current] = TRUE()
)

Avg Utilization % =
AVERAGE(fact_daily_agent_summary[utilization_invites])

Ghost Rate =
1 - DIVIDE([Replies Received], [Messages Sent], BLANK())

Agent Status Bucket =
SWITCH(
    TRUE(),
    [Avg Utilization %] = BLANK(), "No Activity",
    [Avg Utilization %] >= 0.9, "Fully Utilized",
    [Avg Utilization %] >= 0.5, "Active",
    [Avg Utilization %] > 0, "Under-Utilized",
    "Paused / Idle"
)
```

## Risk intelligence measures (consuming Part 5 output)

```dax
Avg Anomaly Score =
AVERAGE(fact_daily_agent_summary[anomaly_score])

Max Anomaly Score (Trailing 7d) =
CALCULATE(
    MAX(fact_daily_agent_summary[anomaly_score]),
    DATESINPERIOD(
        dim_date[full_date],
        MAX(dim_date[full_date]),
        -7,
        DAY
    )
)

Risk Tier =
SWITCH(
    TRUE(),
    ISBLANK([Avg Anomaly Score]), "Insufficient History",
    [Avg Anomaly Score] > 0.6, "High Risk — Throttle Recommended",
    [Avg Anomaly Score] > 0.3, "Elevated — Monitor",
    "Normal"
)

Agents Flagged High Risk =
CALCULATE(
    DISTINCTCOUNT(dim_agent[agent_id]),
    FILTER(fact_daily_agent_summary, fact_daily_agent_summary[anomaly_score] > 0.6)
)
```

## Campaign ROI measures

```dax
Cost Per Reply =
DIVIDE([Total Campaign Cost], [Replies Received], BLANK())
-- NOTE: Total Campaign Cost is a placeholder input measure; this
-- assessment's synthetic data has no cost feed. In production this
-- pulls from a campaign spend table (ad spend / seat cost allocation)
-- joined on campaign_sk. Documented here so the measure layer and the
-- dashboard tile exist and are ready to bind once that source lands.

Replies by Segment =
CALCULATE(
    [Replies Received],
    ALLEXCEPT(dim_campaign, dim_campaign[target_segment])
)

Segment Reply Rate =
DIVIDE([Replies Received], [Messages Sent], BLANK())
-- evaluated in visual/filter context of dim_campaign[target_segment]
```

---

## Required dashboard pages (Part 6 spec)

1. **Overview / Core KPIs** — Invites Sent, Acceptance Rate, Reply Rate,
   Conversion Rate, Throughput vs Limit %, trended daily via `dim_date`.
2. **Account Health** — per-agent card grid using `Agent Status Bucket`,
   `Avg Utilization %`, ghost/paused breakdown as a stacked bar.
3. **Risk Intelligence** — `Risk Tier` matrix by agent/day, `Max Anomaly
   Score (Trailing 7d)` as a heatmap, with a threshold reference line at
   0.6 (the throttle-recommendation threshold from Part 5).
4. **Campaign ROI** — Replies by Segment, Segment Reply Rate, Cost Per
   Reply (pending cost feed), broken out by `dim_campaign[campaign_name]`
   and `[target_segment]`.

All visuals bind exclusively to the explicit measures above — no implicit
aggregations (e.g. no bare `Sum of invites_sent` dragged from the field
list) — so every number on the dashboard has a single, auditable
definition.
