# Polluxa — End-to-End LinkedIn Agent Analytics Platform

Submission for the Data Analyst Assessment (Parts 2–8). See
`docs/part1_evidence.md` for why Part 1 was completed with synthetic
data rather than a live LinkedIn account connection, and what would
change to point this platform at the real API.

## What's here

```
pipeline/
  generate_synthetic_data.py   # stands in for the live Polluxa API extract
  load_warehouse.py            # Part 2 — idempotent, incremental ingestion
  structured_logging.py        # Part 7 — JSON logs + alert conditions
sql/
  01_schema.sql                 # Part 3 — star schema DDL
dq/
  run_dq_checks.py              # Part 4 — 5-dimension DQ suite + composite score
analytics/
  risk_model.py                 # Part 5 — modified z-score anomaly model
powerbi/
  dax_measures.md                # Part 6 — data model + full DAX measure layer
docs/
  data_architecture.md           # Part 3 — end-to-end flow, grain, SCD strategy
  data_dictionary.md             # Part 3 — column-level dictionary
  part1_evidence.md              # Part 1 substitution note
  config.example.env             # secure config pattern
tests/
  test_pipeline.py               # idempotency, DQ gate, bad-data rejection
ci/
  pipeline.yml                    # Part 7 — CI/CD, test-gated deploy
Dockerfile                        # Part 7 — containerized run
```

## Setup

```bash
pip install -r requirements.txt

# 1. Generate the synthetic source extract (data/raw/*.csv)
python pipeline/generate_synthetic_data.py

# 2. Load into the star-schema warehouse (data/warehouse.db)
python pipeline/load_warehouse.py

# 3. Run the data quality gate (exits non-zero on FAIL)
python dq/run_dq_checks.py

# 4. Score anomalies / risk (Part 5)
python analytics/risk_model.py

# 5. Run tests
pytest tests/ -v
```

## Proving the resilience requirements (Part 8 live demo)

- **Idempotent re-run / no duplication:** run `load_warehouse.py` twice —
  the second run's `rows_out` is 0 and `fact_outreach_event` row count is
  unchanged. Enforced by `event_id UNIQUE` + `INSERT OR IGNORE`, and
  covered by `tests/test_pipeline.py::test_pipeline_is_idempotent_on_rerun`.
- **Bad data caught, not silently loaded:** the synthetic generator
  deliberately injects malformed timestamps and orphan lead references;
  both are rejected into `dead_letter_events` with a reason, never
  loaded into the fact table. Covered by
  `test_bad_records_are_captured_in_dead_letter_not_silently_dropped`
  and `test_referential_integrity_orphans_are_rejected`.
- **End-to-end refresh through to the dashboard:** `ci/pipeline.yml`'s
  `refresh_and_gate` job runs ingestion → DQ gate → risk model → publish,
  in that order, failing the workflow (and blocking "deploy") if the DQ
  gate returns FAIL.

## Connecting to a real Polluxa feed

Replace `pipeline/generate_synthetic_data.py`'s CSV output with a real
authenticated API client reading `POLLUXA_API_TOKEN` from the environment
(see `docs/config.example.env`) — `load_warehouse.py`, the schema, DQ
suite, risk model, and Power BI layer are all written against the same
data shape and require no changes.
