-- =====================================================================
-- Polluxa LinkedIn Agent Analytics — Star Schema
-- Target: SQLite for this deliverable (portable to Postgres/Snowflake
-- with minor type changes — see docs/data_architecture.md)
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- DIMENSION: dim_agent
-- Grain: one row per agent per active configuration version (SCD Type 2)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dim_agent (
    agent_sk               INTEGER PRIMARY KEY AUTOINCREMENT,  -- surrogate key
    agent_id                TEXT NOT NULL,                      -- natural/business key
    agent_name              TEXT NOT NULL,
    account_age_tier        TEXT NOT NULL,
    risk_classification     TEXT NOT NULL,
    daily_invite_limit      INTEGER NOT NULL,
    daily_message_limit     INTEGER NOT NULL,
    primary_campaign_id     TEXT,
    status                  TEXT NOT NULL,
    effective_start_ts      TEXT NOT NULL,                      -- SCD2 validity window
    effective_end_ts        TEXT,                                -- NULL = current row
    is_current               INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_dim_agent_natural ON dim_agent (agent_id, is_current);

-- ---------------------------------------------------------------------
-- DIMENSION: dim_lead
-- Grain: one row per lead (SCD Type 1 — attributes overwritten on change,
-- since lead metadata drift doesn't need history for this use case)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dim_lead (
    lead_sk         INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id         TEXT NOT NULL UNIQUE,
    full_name       TEXT,
    title           TEXT,
    industry        TEXT,
    added_date      TEXT,
    load_ts         TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- DIMENSION: dim_campaign
-- Grain: one row per campaign
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dim_campaign (
    campaign_sk     INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id     TEXT NOT NULL UNIQUE,
    campaign_name   TEXT NOT NULL,
    target_segment  TEXT
);

-- ---------------------------------------------------------------------
-- DIMENSION: dim_date
-- Grain: one row per calendar day
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dim_date (
    date_sk         INTEGER PRIMARY KEY,   -- YYYYMMDD
    full_date       TEXT NOT NULL,
    year             INTEGER NOT NULL,
    month            INTEGER NOT NULL,
    month_name       TEXT NOT NULL,
    day              INTEGER NOT NULL,
    day_of_week      TEXT NOT NULL,
    is_weekend       INTEGER NOT NULL
);

-- ---------------------------------------------------------------------
-- FACT: fact_outreach_event
-- Grain: ONE ROW PER OUTREACH EVENT (invite_sent, invite_accepted,
-- message_sent, reply_received) — the lowest-grain event fact.
-- This grain is deliberately chosen (rather than one-row-per-lead)
-- because it preserves full funnel timing and lets every downstream
-- metric (rates, latency, decay curves) be derived rather than
-- pre-aggregated and locked in.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fact_outreach_event (
    event_sk         INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id         TEXT NOT NULL UNIQUE,      -- natural key from source; enforces idempotency
    agent_sk         INTEGER NOT NULL REFERENCES dim_agent(agent_sk),
    lead_sk          INTEGER REFERENCES dim_lead(lead_sk),
    campaign_sk      INTEGER REFERENCES dim_campaign(campaign_sk),
    date_sk          INTEGER REFERENCES dim_date(date_sk),
    event_type       TEXT NOT NULL,             -- invite_sent | invite_accepted | message_sent | reply_received
    event_ts         TEXT NOT NULL,
    account_age_tier TEXT,
    load_ts           TEXT NOT NULL,
    source_run_id     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_fact_event_agent ON fact_outreach_event (agent_sk, event_type, date_sk);
CREATE INDEX IF NOT EXISTS ix_fact_event_lead  ON fact_outreach_event (lead_sk);

-- ---------------------------------------------------------------------
-- FACT: fact_daily_agent_summary
-- Grain: one row per agent per calendar day — pre-aggregated for
-- dashboard performance; derived nightly from fact_outreach_event.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fact_daily_agent_summary (
    summary_sk        INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_sk          INTEGER NOT NULL REFERENCES dim_agent(agent_sk),
    date_sk            INTEGER NOT NULL REFERENCES dim_date(date_sk),
    invites_sent       INTEGER NOT NULL DEFAULT 0,
    invites_accepted   INTEGER NOT NULL DEFAULT 0,
    messages_sent      INTEGER NOT NULL DEFAULT 0,
    replies_received   INTEGER NOT NULL DEFAULT 0,
    acceptance_rate    REAL,
    reply_rate         REAL,
    utilization_invites REAL,   -- invites_sent / daily_invite_limit
    anomaly_score       REAL,   -- populated by Part 5 risk model
    load_ts             TEXT NOT NULL,
    UNIQUE (agent_sk, date_sk)
);

-- ---------------------------------------------------------------------
-- OPERATIONAL: pipeline_run_log  (Part 2 requirement — run metadata)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_run_log (
    run_id          TEXT PRIMARY KEY,
    pipeline_name    TEXT NOT NULL,
    started_at       TEXT NOT NULL,
    ended_at         TEXT,
    status           TEXT NOT NULL,      -- running | success | failed
    rows_in          INTEGER,
    rows_out         INTEGER,
    rows_rejected    INTEGER,
    error_message     TEXT,
    watermark_before  TEXT,
    watermark_after   TEXT
);

-- ---------------------------------------------------------------------
-- OPERATIONAL: dead_letter_events  (Part 2 requirement — bad record capture)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dead_letter_events (
    dead_letter_sk  INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id           TEXT NOT NULL,
    raw_payload      TEXT NOT NULL,
    reject_reason    TEXT NOT NULL,
    rejected_at      TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- OPERATIONAL: dq_results_history  (Part 4 requirement — DQ trending)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_results_history (
    dq_run_sk         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id            TEXT NOT NULL,
    run_ts             TEXT NOT NULL,
    check_name         TEXT NOT NULL,
    dimension          TEXT NOT NULL,   -- completeness | uniqueness | validity | timeliness | referential_integrity
    passed             INTEGER NOT NULL,
    records_checked    INTEGER,
    records_failed     INTEGER,
    detail              TEXT
);

CREATE TABLE IF NOT EXISTS dq_composite_score_history (
    score_run_sk    INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id          TEXT NOT NULL,
    run_ts          TEXT NOT NULL,
    composite_score REAL NOT NULL,
    threshold        REAL NOT NULL,
    result           TEXT NOT NULL   -- PASS | FAIL
);
