"""
risk_model.py

Part 5: Advanced Analytics & Risk Modeling

STATISTICAL METHOD: Modified Z-Score on a rolling baseline (median +
MAD — Median Absolute Deviation), applied per-agent to daily acceptance
rate and reply rate.

WHY THIS METHOD FITS THE DATA:
  - Outreach funnel rates (acceptance %, reply %) are bounded, low-volume
    daily ratios with a small denominator per agent per day (tens of
    events, not thousands). A standard Z-score (mean/stddev) is fragile
    at this volume because a single bad day distorts the mean and
    stddev used to judge itself, and the distribution of daily rates is
    not reliably normal at this sample size.
  - The Modified Z-score uses the median and MAD instead of mean/stddev,
    which are far more robust to the exact kind of outlier we're trying
    to detect (a collapse), and don't require a normality assumption.
  - A rolling baseline (first N "healthy" days per agent, N=14 by
    default) is used rather than a global baseline, because acceptance
    rate is agent- and campaign-specific — a "high" rate for one
    campaign may be "low" for another; each agent is judged against its
    own history, not a cross-agent benchmark.
  - Formula: modified_z = 0.6745 * (x - median) / MAD
    A value with |modified_z| > 3.5 is flagged as anomalous (Iglewicz &
    Hoaglin's standard threshold for the modified Z-score method).

DETECTED RISK SIGNALS:
  - acceptance_rate_collapse: modified Z-score on daily acceptance_rate
  - reply_decay: modified Z-score on daily reply_rate
  - ghosting_spike: a derived metric = messages_sent with zero replies
    over a trailing 7-day window, flagged if it exceeds 70%

OUTPUT: anomaly_score written back to fact_daily_agent_summary
(0.0 = normal, higher = more anomalous; score is the max of the
normalized signal scores below, capped at 1.0 for dashboard readability).

ASSUMPTIONS, CONFIDENCE, AND LIMITATIONS (Part 5 requirement):
  - Assumes at least 14 days of baseline history per agent before the
    score is meaningful; agents with less history get anomaly_score =
    NULL rather than a possibly-misleading score.
  - Assumes each agent's outreach targets a roughly consistent audience
    quality over time; a genuine change in target segment (not a
    platform-side problem) can also trigger this score and would need
    analyst review to distinguish from a real risk event (e.g.
    shadow-banning) — the model flags, it does not diagnose cause.
  - Confidence: the |z| > 3.5 threshold is a standard robust-outlier
    convention, not tuned against real ground-truth shadow-ban labels
    (none were available). Recommend re-calibrating the threshold once
    confirmed shadow-ban / restriction events are logged.
  - Low daily volume (5-30 invites/day per the tier limits) means a
    single accept/decline can swing the daily rate by several
    percentage points — the model is more reliable at a 7-day rolling
    aggregation than on single-day spikes; both are computed but the
    7-day view should be primary for capacity decisions.

RECOMMENDED DAILY CAPACITY LIMITS:
  For any agent-day where anomaly_score > 0.6, recommend capping that
  day's invite volume at 50% of the tier ceiling from Part 1 until the
  rolling acceptance rate recovers to within 1.5x MAD of its baseline
  median. This is intentionally more conservative than the platform's
  own static tier ceiling, because the tier ceiling is a fixed
  account-age heuristic, not a response to observed behavior — the
  ceiling protects against generic risk, this model responds to
  *evidenced* risk on top of it.
"""

import os
import sqlite3
import statistics
from datetime import datetime, timezone

BASE_DIR = os.path.join(os.path.dirname(__file__), "..")
DB_PATH = os.path.join(BASE_DIR, "data", "warehouse.db")

BASELINE_MIN_DAYS = 14
MODIFIED_Z_THRESHOLD = 3.5
GHOST_RATE_THRESHOLD = 0.70

# Funnel warm-up / cold-start exclusion: invite -> accept -> message -> reply
# can span up to ~72h + 48h + 96h in this data. In the first few days after
# an agent starts, the message/reply *counts* per day are thin simply
# because the funnel hasn't had time to flow through yet -- not because
# anything is wrong. Scoring or baselining on those days causes false
# positives from small-denominator noise, not real risk signal. Both the
# baseline window and the scored window start after this warm-up period.
WARMUP_DAYS = 5

# Symmetric issue at the *end* of the observation window: replies can land
# up to ~9 days (72h+48h+96h) after their originating invite, so the most
# recent ~9 days in any extract are right-censored -- their "final" reply
# counts haven't arrived yet. Those trailing days are excluded from scoring
# for the same reason WARMUP_DAYS are excluded from the front. In
# production this window shrinks to whatever the pipeline's true max
# funnel latency is, measured from real data.
TAIL_CENSORED_DAYS = 9


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    return conn


def modified_z_scores(values):
    """Returns modified z-score for each value in the series, robust to outliers."""
    median = statistics.median(values)
    abs_devs = [abs(v - median) for v in values]
    mad = statistics.median(abs_devs)
    if mad == 0:
        # fall back to mean absolute deviation to avoid division by zero
        mad = sum(abs_devs) / len(abs_devs) if abs_devs else 1e-9
        if mad == 0:
            return [0.0 for _ in values]
    return [0.6745 * (v - median) / mad for v in values]


def compute_agent_anomalies(conn, agent_sk, extract_max_date):
    rows = conn.execute("""
        SELECT s.date_sk, d.full_date, s.acceptance_rate, s.reply_rate,
               s.messages_sent, s.replies_received
        FROM fact_daily_agent_summary s
        JOIN dim_date d ON d.date_sk = s.date_sk
        WHERE s.agent_sk = ?
        ORDER BY d.full_date
    """, (agent_sk,)).fetchall()

    rows = rows[WARMUP_DAYS:]  # drop cold-start days; see WARMUP_DAYS docstring note

    cutoff = extract_max_date - __import__("datetime").timedelta(days=TAIL_CENSORED_DAYS)
    rows = [r for r in rows if datetime.fromisoformat(r[1]).date() <= cutoff]

    if len(rows) < BASELINE_MIN_DAYS:
        return []  # not enough history for a meaningful baseline

    baseline_rows = rows[:BASELINE_MIN_DAYS]
    baseline_accept = [r[2] for r in baseline_rows if r[2] is not None]
    baseline_reply = [r[3] for r in baseline_rows if r[3] is not None]

    results = []
    accept_series = [r[2] if r[2] is not None else 0.0 for r in rows]
    reply_series = [r[3] if r[3] is not None else 0.0 for r in rows]

    accept_z = modified_z_scores(baseline_accept + accept_series[BASELINE_MIN_DAYS:]) if baseline_accept else [0]*len(rows)
    # recompute z per point against fixed baseline stats for clarity/stability:
    baseline_median_a = statistics.median(baseline_accept) if baseline_accept else 0
    baseline_mad_a = statistics.median([abs(v - baseline_median_a) for v in baseline_accept]) if baseline_accept else 0
    baseline_median_r = statistics.median(baseline_reply) if baseline_reply else 0
    baseline_mad_r = statistics.median([abs(v - baseline_median_r) for v in baseline_reply]) if baseline_reply else 0

    # Practical floor on MAD: at low daily event volume (5-30 invites/day
    # per the Part 1 tier limits), a handful of consecutive "typical" days
    # can produce a near-zero MAD, which makes the z-score formula blow up
    # and flag ordinary noise as a severe anomaly. A floor of 0.05 (5
    # percentage points of rate) prevents this hypersensitivity while still
    # allowing genuine large collapses to score highly. This floor is a
    # documented, tunable assumption — see module docstring limitations.
    MAD_FLOOR = 0.05

    def z(v, med, mad):
        mad = max(mad, MAD_FLOOR)
        return 0.6745 * (v - med) / mad

    # trailing 7-day ghost rate
    for i, r in enumerate(rows):
        date_sk, full_date, accept_rate, reply_rate, msgs, replies = r
        az = z(accept_rate if accept_rate is not None else 0, baseline_median_a, baseline_mad_a)
        rz = z(reply_rate if reply_rate is not None else 0, baseline_median_r, baseline_mad_r)

        window = rows[max(0, i - 6): i + 1]
        window_msgs = sum(w[4] or 0 for w in window)
        window_replies = sum(w[5] or 0 for w in window)
        ghost_rate = 1 - (window_replies / window_msgs) if window_msgs else 0

        # only negative deviations (collapse/decay) are "risk" — a spike UP
        # in acceptance rate is good news, not anomalous risk.
        accept_signal = max(0.0, -az) / MODIFIED_Z_THRESHOLD
        reply_signal = max(0.0, -rz) / MODIFIED_Z_THRESHOLD
        ghost_signal = max(0.0, (ghost_rate - GHOST_RATE_THRESHOLD) / (1 - GHOST_RATE_THRESHOLD)) if ghost_rate > GHOST_RATE_THRESHOLD else 0.0

        anomaly_score = min(1.0, max(accept_signal, reply_signal, ghost_signal))

        # first BASELINE_MIN_DAYS are the baseline itself — score them too,
        # but they define the baseline so scores near 0 are expected there.
        results.append((date_sk, round(anomaly_score, 4)))

    return results


def run_risk_model():
    conn = get_conn()
    conn.execute("UPDATE fact_daily_agent_summary SET anomaly_score = NULL")
    conn.commit()
    agents = conn.execute("SELECT DISTINCT agent_sk FROM fact_daily_agent_summary").fetchall()
    max_date_str = conn.execute("SELECT MAX(full_date) FROM dim_date").fetchone()[0]
    extract_max_date = datetime.fromisoformat(max_date_str).date()

    flagged_agent_days = []
    for (agent_sk,) in agents:
        scores = compute_agent_anomalies(conn, agent_sk, extract_max_date)
        for date_sk, score in scores:
            conn.execute("""
                UPDATE fact_daily_agent_summary SET anomaly_score = ?
                WHERE agent_sk = ? AND date_sk = ?
            """, (score, agent_sk, date_sk))
            if score > 0.6:
                flagged_agent_days.append((agent_sk, date_sk, score))

    conn.commit()

    agent_names = dict(conn.execute("SELECT agent_sk, agent_id FROM dim_agent WHERE is_current = 1").fetchall())
    print(f"Scored anomalies for {len(agents)} agents.")
    print(f"Flagged {len(flagged_agent_days)} agent-days with anomaly_score > 0.6 "
          f"(recommend capacity throttle to 50% of tier ceiling):")
    for agent_sk, date_sk, score in sorted(flagged_agent_days, key=lambda x: -x[2])[:15]:
        print(f"  agent={agent_names.get(agent_sk)} date_sk={date_sk} score={score}")

    conn.close()


if __name__ == "__main__":
    run_risk_model()
