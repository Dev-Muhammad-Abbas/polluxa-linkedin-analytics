# Data Architecture & Flow

## End-to-end flow

```
Polluxa LinkedIn Agent API (live outreach events, leads, agents, campaigns)
        │  [in this assessment: pipeline/generate_synthetic_data.py
        │   stands in for this API — see docs/part1_evidence.md]
        ▼
Staging (data/raw/*.csv)  — raw extract, one file per source entity
        │  simulate_api_fetch() retry+backoff wrapper
        ▼
pipeline/load_warehouse.py
        │  - upsert dimensions (SCD1 for lead/campaign, SCD2 for agent)
        │  - incremental fact load, filtered by watermark
        │  - malformed / unresolvable rows → dead_letter_events
        │  - run metadata → pipeline_run_log
        ▼
Star Schema Warehouse (data/warehouse.db)
    dim_agent (SCD2) · dim_lead (SCD1) · dim_campaign · dim_date
    fact_outreach_event (event grain)
    fact_daily_agent_summary (agent/day grain, derived)
        │
        ├─▶ dq/run_dq_checks.py  → dq_results_history, dq_composite_score_history
        │        (gates promotion: non-zero exit on FAIL — see Part 7 CI/CD)
        │
        └─▶ analytics/risk_model.py → writes anomaly_score back onto
                 fact_daily_agent_summary
        ▼
Presentation layer: Power BI (powerbi/dax_measures.md)
    imports dim_* and fact_* tables, measure layer defined in DAX
```

## Grain declarations

| Table | Grain | Primary/Natural Key |
|---|---|---|
| `dim_agent` | one row per agent per SCD2 version | `agent_id` (natural), `agent_sk` (surrogate) |
| `dim_lead` | one row per lead | `lead_id` (natural), `lead_sk` (surrogate) |
| `dim_campaign` | one row per campaign | `campaign_id` (natural), `campaign_sk` (surrogate) |
| `dim_date` | one row per calendar day | `date_sk` (YYYYMMDD int) |
| `fact_outreach_event` | one row per funnel event (invite/accept/message/reply) | `event_id` (natural, UNIQUE), `event_sk` (surrogate) |
| `fact_daily_agent_summary` | one row per agent per day | (`agent_sk`, `date_sk`) composite, UNIQUE |

## Surrogate keys & SCD strategy

- All dimension and fact tables use auto-incrementing integer surrogate
  keys (`*_sk`) as the join keys used throughout the model; natural/business
  keys (`agent_id`, `lead_id`, etc.) are retained as attributes for
  traceability back to source but are never used as join keys, so a
  source-side key format change doesn't break the model.
- `dim_agent` is **SCD Type 2**: `account_age_tier`, the two daily limits,
  and `status` are tracked with full history (`effective_start_ts`,
  `effective_end_ts`, `is_current`), because an agent's tier and limits
  changing over time is itself analytically meaningful (Part 5's risk
  model needs to know what ceiling was in force on a given day, not just
  today's ceiling).
- `dim_lead` and `dim_campaign` are **SCD Type 1** (overwrite on change) —
  their attributes (title, industry, campaign name) are reference metadata
  where historical tracking isn't needed for this use case.

## Why event-grain + a derived daily-summary fact (not just one)

`fact_outreach_event` is the source of truth and lowest grain — it's what
makes the pipeline idempotent (unique `event_id`) and lets the risk model
compute true event-timing signals (accept latency, reply latency).
`fact_daily_agent_summary` is a derived, idempotently-rebuilt rollup
(`DELETE + re-INSERT` from the event fact every run) that exists purely
for dashboard query performance and as the anchor table for the
Part 5 anomaly score — Power BI never has to aggregate the full event
fact live for the core KPI visuals.

## Data dictionary

See `docs/data_dictionary.md` for the full column-level dictionary.
