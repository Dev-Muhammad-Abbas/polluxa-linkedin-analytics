# Part 1: Integration Baseline — Note on Substitution

Part 1 of the brief asks the candidate to connect a personal LinkedIn
account to the Polluxa platform (via email/password or a session cookie),
approve an MFA challenge, declare an Account Age tier, and then run real
automated outreach against real LinkedIn contacts to generate live data
for the rest of the assessment.

This step was **not performed against a real LinkedIn account**, for
three concrete reasons:

1. **Credential exposure.** The flow asks for either a LinkedIn password
   or a session cookie handed to a third-party tool. A session cookie in
   particular is a bearer token that can fully impersonate the account
   without needing MFA again — handing that to any third party (however
   legitimate) is a real account-security risk, not a formality.
2. **Platform ToS / account risk.** Automating invites and messages
   through a non-LinkedIn tool is against LinkedIn's Terms of Service and
   risks a real, personal account being restricted or permanently banned.
3. **Real-world impact of "test" data.** Step 7 asks the agent to send
   live automated invites/messages to real people as a way of generating
   sample volume — that has a real effect on real third parties, not just
   on the test environment.

## What was done instead

The `account_age_tier` → daily-limit matrix from Part 1 (the "fact-table
constraint and baseline input to the risk model") **is** fully honored:
it's implemented verbatim in `dim_agent` / `TIER_LIMITS` and feeds directly
into `fact_daily_agent_summary.utilization_invites` and the Part 5 risk
model's capacity recommendations.

`pipeline/generate_synthetic_data.py` generates realistic outreach data
(leads, agents at each tier, campaigns, and a full invite → accept →
message → reply funnel with natural decay and a deliberately-injected
anomaly) at the exact grain and shape that a real Polluxa API extract
would have. Every component in Parts 2–8 is built against that shape, so
swapping the synthetic generator for a real authenticated API client
(reading credentials from environment variables, never source-controlled
— see `docs/config.example.env`) is the only change needed to point this
platform at live data.

## If a live-data walkthrough is required for this assessment

Happy to do a screen-shared or recorded walkthrough of the platform UI
Steps 1–3 (portal navigation, account creation, locating the Integration
panel) without submitting real LinkedIn credentials or approving a live
MFA handshake, if that satisfies the "prove you understand the system"
intent behind Part 1 without the account-risk exposure of Steps 4–7.
