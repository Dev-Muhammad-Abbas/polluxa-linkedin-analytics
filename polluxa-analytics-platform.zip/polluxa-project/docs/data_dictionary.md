# Data Dictionary

## dim_agent
| Column | Type | Definition |
|---|---|---|
| agent_sk | INTEGER PK | Surrogate key, join key for all facts |
| agent_id | TEXT | Natural key from source system |
| agent_name | TEXT | Human-readable agent/account label |
| account_age_tier | TEXT | Tier declared in Part 1 (`<1_month` … `1_year_plus`) |
| risk_classification | TEXT | Platform's risk label for the tier |
| daily_invite_limit | INTEGER | Max invites/day enforced by the tier |
| daily_message_limit | INTEGER | Max messages/day enforced by the tier |
| primary_campaign_id | TEXT | Campaign this agent is primarily assigned to |
| status | TEXT | `active` / `paused` / etc. |
| effective_start_ts / effective_end_ts | TEXT | SCD2 validity window |
| is_current | INTEGER (bool) | 1 = current version of this agent's record |

## dim_lead
| Column | Type | Definition |
|---|---|---|
| lead_sk | INTEGER PK | Surrogate key |
| lead_id | TEXT UNIQUE | Natural key from source |
| full_name | TEXT | Lead's display name |
| title | TEXT | Job title at time of load (may be blank — see DQ completeness check) |
| industry | TEXT | Industry category |
| added_date | TEXT (date) | Date the lead was added to a campaign |
| load_ts | TEXT (timestamp) | Warehouse load timestamp |

## dim_campaign
| Column | Type | Definition |
|---|---|---|
| campaign_sk | INTEGER PK | Surrogate key |
| campaign_id | TEXT UNIQUE | Natural key |
| campaign_name | TEXT | Display name |
| target_segment | TEXT | Business segment the campaign targets (`Recruiting`, `Sales`) |

## dim_date
Standard calendar date dimension, `date_sk` = `YYYYMMDD` integer.

## fact_outreach_event
| Column | Type | Definition |
|---|---|---|
| event_sk | INTEGER PK | Surrogate key |
| event_id | TEXT UNIQUE | Natural key from source; enforces idempotent load |
| agent_sk / lead_sk / campaign_sk / date_sk | INTEGER FK | Dimension links |
| event_type | TEXT | One of `invite_sent`, `invite_accepted`, `message_sent`, `reply_received` |
| event_ts | TEXT (ISO 8601) | Timestamp the event occurred |
| account_age_tier | TEXT | Tier in force for the agent at event time (denormalized for point-in-time accuracy even if the agent's tier later changes) |
| load_ts | TEXT | Warehouse load timestamp |
| source_run_id | TEXT | `pipeline_run_log.run_id` that loaded this row |

## fact_daily_agent_summary
| Column | Type | Definition |
|---|---|---|
| summary_sk | INTEGER PK | Surrogate key |
| agent_sk / date_sk | INTEGER FK | Composite business key (UNIQUE) |
| invites_sent / invites_accepted / messages_sent / replies_received | INTEGER | Daily event counts by type |
| acceptance_rate | REAL | `invites_accepted / invites_sent` |
| reply_rate | REAL | `replies_received / messages_sent` |
| utilization_invites | REAL | `invites_sent / daily_invite_limit` |
| anomaly_score | REAL | 0–1 risk score from the Part 5 model; NULL if agent has &lt;19 days of qualifying history (14-day baseline + 5-day warm-up exclusion) |

## Operational tables
- **pipeline_run_log**: one row per pipeline execution — start/end time,
  status, rows in/out/rejected, watermark before/after.
- **dead_letter_events**: raw JSON payload + reject reason for every row
  that failed to load (missing timestamp, unresolvable lead/agent key).
- **dq_results_history**: one row per individual DQ check per run.
- **dq_composite_score_history**: one row per run with the weighted
  composite score and PASS/FAIL result.
