"""
generate_synthetic_data.py

Generates realistic synthetic LinkedIn outreach data to stand in for a live
Polluxa agent feed for this assessment.

WHY SYNTHETIC DATA:
Part 1 of the assessment brief requires connecting a real LinkedIn account
(email/password or session cookie) to a third-party automation tool and
running live automated outreach against real contacts. This was intentionally
NOT done because:
  1. It requires handing a third party LinkedIn credentials or a session
     cookie, which is a full account-takeover-level credential.
  2. Running automated bulk outreach violates LinkedIn's Terms of Service
     and risks a permanent account restriction.
  3. It would send real automated messages to real people as a "test."

Everything downstream (Parts 2-8: pipeline, schema, DQ, risk modeling,
Power BI, DevOps) is built to the same specification and grain that live
agent data would have, so the entire system is a drop-in replacement: point
the ingestion layer at the real Polluxa API instead of this generator and
the rest of the platform is unchanged.

The generator simulates:
  - Multiple LinkedIn agents (accounts) at different "Account Age" tiers
    (per the tier -> daily limit matrix in Part 1 of the brief)
  - Leads added across campaigns / target segments
  - Funnel events: invite_sent -> invite_accepted -> message_sent -> reply
  - Natural decay/ghosting patterns
  - A few deliberately-injected data quality problems (dupes, nulls, bad
    timestamps, orphan keys) so Part 4's DQ checks have something to catch
  - A deliberately-injected anomaly (one agent's acceptance rate collapses
    for several days) so Part 5's risk model has a real signal to detect
"""

import csv
import json
import os
import random
import uuid
from datetime import datetime, timedelta

random.seed(42)

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
os.makedirs(OUT_DIR, exist_ok=True)

TIER_LIMITS = {
    "<1_month":   {"risk": "Very High Risk", "daily_invites": 5,  "daily_messages": 10},
    "1_month":    {"risk": "High Risk",      "daily_invites": 10, "daily_messages": 15},
    "2_6_months": {"risk": "Moderate Risk",  "daily_invites": 15, "daily_messages": 25},
    "6_12_months":{"risk": "Low Risk",       "daily_invites": 25, "daily_messages": 40},
    "1_year_plus":{"risk": "Minimal Risk",   "daily_invites": 30, "daily_messages": 60},
}

CAMPAIGNS = [
    ("CMP-001", "Recruiter Outreach - Backend Engineers", "Recruiting"),
    ("CMP-002", "SaaS Founders - Series A/B", "Sales"),
    ("CMP-003", "Data Analyst Talent Pool", "Recruiting"),
    ("CMP-004", "Marketing Agency Leads", "Sales"),
]

AGENTS = [
    ("AGT-01", "Recruiting Bot Alpha", "1_year_plus", "CMP-001"),
    ("AGT-02", "Sales Outreach Beta", "6_12_months", "CMP-002"),
    ("AGT-03", "Talent Pool Gamma", "2_6_months", "CMP-003"),
    ("AGT-04", "Agency Leads Delta", "1_month", "CMP-004"),
    ("AGT-05", "New Account Epsilon", "<1_month", "CMP-004"),
]

# Agent that will suffer a deliberate acceptance-rate collapse (anomaly
# for Part 5 to detect) starting on day 20 of the simulation window.
ANOMALY_AGENT = "AGT-02"
ANOMALY_START_DAY = 20
SIM_DAYS = 35
START_DATE = datetime(2026, 7, 1)


def rand_ts(day_offset, hour_start=8, hour_end=18):
    d = START_DATE + timedelta(days=day_offset)
    h = random.randint(hour_start, hour_end)
    m = random.randint(0, 59)
    s = random.randint(0, 59)
    return d.replace(hour=h, minute=m, second=s)


def gen_leads(n=600):
    titles = ["Software Engineer", "Data Analyst", "Product Manager", "Founder",
              "VP Sales", "Marketing Director", "ML Engineer", "Recruiter", "CTO", "Growth Lead"]
    industries = ["Technology", "Finance", "Healthcare", "Retail", "Education", "Manufacturing"]
    rows = []
    for i in range(n):
        campaign = random.choice(CAMPAIGNS)
        rows.append({
            "lead_id": f"LEAD-{i+1:05d}",
            "full_name": f"Lead Person {i+1}",
            "title": random.choice(titles),
            "industry": random.choice(industries),
            "campaign_id": campaign[0],
            "target_segment": campaign[2],
            "added_date": (START_DATE + timedelta(days=random.randint(0, SIM_DAYS - 1))).strftime("%Y-%m-%d"),
        })
    # inject a few duplicate lead_ids (data quality issue for Part 4)
    for _ in range(8):
        dup = random.choice(rows).copy()
        rows.append(dup)
    # inject a few leads with null/blank title (completeness issue)
    for _ in range(10):
        rows[random.randint(0, len(rows) - 1)]["title"] = ""
    return rows


def gen_events(leads):
    """Generate the invite -> accept -> message -> reply funnel per agent/day."""
    events = []
    leads_by_campaign = {}
    for l in leads:
        leads_by_campaign.setdefault(l["campaign_id"], []).append(l)

    for agent_id, agent_name, tier, campaign_id in AGENTS:
        limits = TIER_LIMITS[tier]
        candidate_leads = leads_by_campaign.get(campaign_id, [])
        if not candidate_leads:
            continue

        base_accept_rate = random.uniform(0.35, 0.55)
        base_reply_rate = random.uniform(0.25, 0.45)

        for day in range(SIM_DAYS):
            accept_rate = base_accept_rate
            reply_rate = base_reply_rate

            # Deliberate anomaly injection: acceptance rate collapses for
            # ANOMALY_AGENT starting at ANOMALY_START_DAY, recovering slowly.
            if agent_id == ANOMALY_AGENT and day >= ANOMALY_START_DAY:
                days_into_anomaly = day - ANOMALY_START_DAY
                accept_rate = max(0.03, base_accept_rate * (0.15 if days_into_anomaly < 8 else 0.4))
                reply_rate = max(0.02, base_reply_rate * 0.3)

            n_invites = random.randint(int(limits["daily_invites"] * 0.6), limits["daily_invites"])
            day_leads = random.sample(candidate_leads, min(n_invites, len(candidate_leads)))

            for lead in day_leads:
                invite_id = str(uuid.uuid4())
                invite_ts = rand_ts(day)
                invite_status = "sent"

                # occasionally simulate an invite with a malformed/missing timestamp
                bad_ts = random.random() < 0.004

                events.append({
                    "event_id": invite_id,
                    "agent_id": agent_id,
                    "lead_id": lead["lead_id"],
                    "campaign_id": campaign_id,
                    "event_type": "invite_sent",
                    "event_ts": "" if bad_ts else invite_ts.isoformat(),
                    "account_age_tier": tier,
                })

                accepted = random.random() < accept_rate
                if accepted:
                    accept_ts = invite_ts + timedelta(hours=random.randint(1, 72))
                    events.append({
                        "event_id": str(uuid.uuid4()),
                        "agent_id": agent_id,
                        "lead_id": lead["lead_id"],
                        "campaign_id": campaign_id,
                        "event_type": "invite_accepted",
                        "event_ts": accept_ts.isoformat(),
                        "account_age_tier": tier,
                    })

                    messaged = random.random() < 0.85
                    if messaged:
                        msg_ts = accept_ts + timedelta(hours=random.randint(1, 48))
                        events.append({
                            "event_id": str(uuid.uuid4()),
                            "agent_id": agent_id,
                            "lead_id": lead["lead_id"],
                            "campaign_id": campaign_id,
                            "event_type": "message_sent",
                            "event_ts": msg_ts.isoformat(),
                            "account_age_tier": tier,
                        })

                        replied = random.random() < reply_rate
                        if replied:
                            reply_ts = msg_ts + timedelta(hours=random.randint(1, 96))
                            events.append({
                                "event_id": str(uuid.uuid4()),
                                "agent_id": agent_id,
                                "lead_id": lead["lead_id"],
                                "campaign_id": campaign_id,
                                "event_type": "reply_received",
                                "event_ts": reply_ts.isoformat(),
                                "account_age_tier": tier,
                            })
                        else:
                            # ghosted after message: no reply
                            pass

    # inject a handful of orphan events referencing a lead_id that doesn't exist
    # (referential integrity issue for Part 4)
    for _ in range(6):
        events.append({
            "event_id": str(uuid.uuid4()),
            "agent_id": random.choice(AGENTS)[0],
            "lead_id": f"LEAD-{99000 + random.randint(1, 999)}",
            "campaign_id": random.choice(CAMPAIGNS)[0],
            "event_type": "invite_sent",
            "event_ts": rand_ts(random.randint(0, SIM_DAYS - 1)).isoformat(),
            "account_age_tier": "unknown",
        })

    # inject duplicate events (idempotency test fixture for Part 2)
    for _ in range(15):
        events.append(random.choice(events).copy())

    return events


def gen_agents_dim():
    rows = []
    for agent_id, agent_name, tier, campaign_id in AGENTS:
        limits = TIER_LIMITS[tier]
        rows.append({
            "agent_id": agent_id,
            "agent_name": agent_name,
            "account_age_tier": tier,
            "risk_classification": limits["risk"],
            "daily_invite_limit": limits["daily_invites"],
            "daily_message_limit": limits["daily_messages"],
            "primary_campaign_id": campaign_id,
            "status": "active",
        })
    return rows


def gen_campaigns_dim():
    rows = []
    for campaign_id, name, segment in CAMPAIGNS:
        rows.append({
            "campaign_id": campaign_id,
            "campaign_name": name,
            "target_segment": segment,
        })
    return rows


def write_csv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    leads = gen_leads()
    events = gen_events(leads)
    agents = gen_agents_dim()
    campaigns = gen_campaigns_dim()

    write_csv(os.path.join(OUT_DIR, "leads.csv"), leads,
              ["lead_id", "full_name", "title", "industry", "campaign_id", "target_segment", "added_date"])
    write_csv(os.path.join(OUT_DIR, "events.csv"), events,
              ["event_id", "agent_id", "lead_id", "campaign_id", "event_type", "event_ts", "account_age_tier"])
    write_csv(os.path.join(OUT_DIR, "agents.csv"), agents,
              ["agent_id", "agent_name", "account_age_tier", "risk_classification",
               "daily_invite_limit", "daily_message_limit", "primary_campaign_id", "status"])
    write_csv(os.path.join(OUT_DIR, "campaigns.csv"), campaigns,
              ["campaign_id", "campaign_name", "target_segment"])

    print(f"Generated {len(leads)} leads, {len(events)} events, "
          f"{len(agents)} agents, {len(campaigns)} campaigns -> {OUT_DIR}")
