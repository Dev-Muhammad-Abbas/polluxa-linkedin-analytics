"""
structured_logging.py

Part 7: Observability

Machine-parseable JSON logging with a correlation ID (the pipeline
run_id) threaded through every log line for a given run, so a full
pipeline execution can be reconstructed from log aggregation tooling
(e.g. CloudWatch Logs Insights, Datadog, Loki) by filtering on
correlation_id alone.

Also implements the three alert conditions required by Part 7:
  - pipeline failure
  - DQ threshold breach
  - anomalous run duration (> 2x the trailing 7-run average)
"""

import json
import sys
import time
from datetime import datetime, timezone


class StructuredLogger:
    def __init__(self, correlation_id: str, component: str):
        self.correlation_id = correlation_id
        self.component = component

    def _emit(self, level, message, **fields):
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": level,
            "component": self.component,
            "correlation_id": self.correlation_id,
            "message": message,
            **fields,
        }
        print(json.dumps(record), file=sys.stdout if level != "ERROR" else sys.stderr)

    def info(self, message, **fields):
        self._emit("INFO", message, **fields)

    def warn(self, message, **fields):
        self._emit("WARN", message, **fields)

    def error(self, message, **fields):
        self._emit("ERROR", message, **fields)


def check_run_duration_anomaly(conn, current_run_id, current_duration_seconds, lookback=7):
    """Alert condition: current run duration > 2x trailing average."""
    rows = conn.execute("""
        SELECT started_at, ended_at FROM pipeline_run_log
        WHERE status = 'success' AND run_id != ?
        ORDER BY started_at DESC LIMIT ?
    """, (current_run_id, lookback)).fetchall()

    durations = []
    for started_at, ended_at in rows:
        if started_at and ended_at:
            d = (datetime.fromisoformat(ended_at) - datetime.fromisoformat(started_at)).total_seconds()
            durations.append(d)

    if not durations:
        return False, None

    avg = sum(durations) / len(durations)
    is_anomalous = current_duration_seconds > 2 * avg
    return is_anomalous, avg


def send_alert(channel: str, message: str, severity: str = "critical"):
    """Stub alert dispatcher. In production this posts to a Slack
    webhook / PagerDuty Events API / SNS topic — endpoint read from
    environment config, never hardcoded."""
    print(json.dumps({
        "ts": datetime.now(timezone.utc).isoformat(),
        "alert_channel": channel,
        "severity": severity,
        "message": message,
    }))
